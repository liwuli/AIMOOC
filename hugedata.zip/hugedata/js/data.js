// 准备数据项
let indicator = [{
		name: '教学态度',
		max: 300
	},
	{
		name: '教学目标',
		max: 250
	},
	{
		name: '教学效果',
		max: 300
	},
	{
		name: '教学方法',
		max: 5
	},
	{
		name: '教学内容',
		max: 200
	}
]

let indicatorone = [{
		name: '高兴',
		max: 300
	},
	{
		name: '悲伤',
		max: 250
	},
	{
		name: '生气',
		max: 300
	},
	{
		name: '害怕',
		max: 10
	},
	{
		name: '无表情',
		max: 200
	}
]

// 柱状图数组 教学态度 共150组数据
let zztdata = [{
		data: [
			[182, 191, 234, 290], //教学态度
			[182, 191, 34, 290], // 教学内容
			[182, 191, 234, 290], // 教学方法
			[182, 191, 34, 290], // 教学效果
			[182, 191, 234, 290], //教学目标
		],
		zztxaxis: [
			['条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度']
		]
	},
	{
		data: [
			[220, 182, 191, 234, 290], //教学态度
			[220, 182, 191, 34, 290], // 教学内容
			[20, 182, 191, 234, 290], // 教学方法
			[220, 182, 191, 34, 290], // 教学效果
			[20, 182, 191, 234, 290], //教学目标
		],
		zztxaxis: [
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度']
		]
	},
	{
		data: [
			[220, 182, 191, 234, 290], //教学态度
			[220, 182, 191, 34, 290], // 教学内容
			[20, 182, 191, 234, 290], // 教学方法
			[220, 182, 191, 34, 290], // 教学效果
			[20, 182, 191, 234, 290], //教学目标
		],
		zztxaxis: [
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度']
		]
	},
	{
		data: [
			[220, 182, 191, 234, 290], //教学态度
			[220, 182, 191, 34, 290], // 教学内容
			[20, 182, 191, 234, 290], // 教学方法
			[220, 182, 191, 34, 290], // 教学效果
			[20, 182, 191, 234, 290], //教学目标
		],
		zztxaxis: [
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度']
		]
	},
	{
		data: [
			[220, 182, 191, 234, 290], //教学态度
			[220, 182, 191, 34, 290], // 教学内容
			[20, 182, 191, 234, 290], // 教学方法
			[220, 182, 191, 34, 290], // 教学效果
			[20, 182, 191, 234, 290], //教学目标
		],
		zztxaxis: [
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度']
		]
	},
	{
		data: [
			[220, 182, 191, 234, 290], //教学态度
			[220, 182, 191, 34, 290], // 教学内容
			[20, 182, 191, 234, 290], // 教学方法
			[220, 182, 191, 34, 290], // 教学效果
			[20, 182, 191, 234, 290], //教学目标
		],
		zztxaxis: [
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度']
		]
	},
	{
		data: [
			[220, 182, 191, 234, 290], //教学态度
			[220, 182, 191, 34, 290], // 教学内容
			[20, 182, 191, 234, 290], // 教学方法
			[220, 182, 191, 34, 290], // 教学效果
			[20, 182, 191, 234, 290], //教学目标
		],
		zztxaxis: [
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度']
		]
	},
	{
		data: [
			[220, 182, 191, 234, 290], //教学态度
			[220, 182, 191, 34, 290], // 教学内容
			[20, 182, 191, 234, 290], // 教学方法
			[220, 182, 191, 34, 290], // 教学效果
			[20, 182, 191, 234, 290], //教学目标
		],
		zztxaxis: [
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度']
		]
	},
	{
		data: [
			[220, 182, 191, 234, 290], //教学态度
			[220, 182, 191, 34, 290], // 教学内容
			[20, 182, 191, 234, 290], // 教学方法
			[220, 182, 191, 34, 290], // 教学效果
			[20, 182, 191, 234, 290], //教学目标
		],
		zztxaxis: [
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度']
		]
	},
	{
		data: [
			[220, 182, 191, 234, 290], //教学态度
			[220, 182, 191, 34, 290], // 教学内容
			[20, 182, 191, 234, 290], // 教学方法
			[220, 182, 191, 34, 290], // 教学效果
			[20, 182, 191, 234, 290], //教学目标
		],
		zztxaxis: [
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度'],
			['准确性\n\n科学性', '条理性\n\n逻辑性', '重点难\n\n点把握', '内容丰\n\n富性', '前瞻性\n\n严谨度']
		]
	}
]

// 板书数组  二维数组  数组第一项名称为空， 第二项名称为显示的百分比，value同name相同 第一项的value和第二项的value和为100
// 师生互动部分
let stdata = [
	[{
		value: 90,
		name: ''
	}, {
		value: 10,
		name: '10%'
	}],
	[{
		value: 80,
		name: ''
	}, {
		value: 20,
		name: '20%'
	}],
	[{
		value: 70,
		name: ''
	}, {
		value: 30,
		name: '30%'
	}],
	[{
		value: 60,
		name: ''
	}, {
		value: 40,
		name: '40%'
	}],
	[{
		value: 50,
		name: ''
	}, {
		value: 50,
		name: '50%'
	}],
	[{
		value: 90,
		name: ''
	}, {
		value: 10,
		name: '10%'
	}],
	[{
		value: 80,
		name: ''
	}, {
		value: 20,
		name: '20%'
	}],
	[{
		value: 70,
		name: ''
	}, {
		value: 30,
		name: '30%'
	}],
	[{
		value: 60,
		name: ''
	}, {
		value: 40,
		name: '40%'
	}],
	[{
		value: 50,
		name: ''
	}, {
		value: 50,
		name: '50%'
	}]
]
// 板书部分，同stdata
let bsdata = [
	[{
		value: 90,
		name: ''
	}, {
		value: 10,
		name: '10%'
	}],
	[{
		value: 80,
		name: ''
	}, {
		value: 20,
		name: '20%'
	}],
	[{
		value: 70,
		name: ''
	}, {
		value: 30,
		name: '30%'
	}],
	[{
		value: 60,
		name: ''
	}, {
		value: 40,
		name: '40%'
	}],
	[{
		value: 50,
		name: ''
	}, {
		value: 50,
		name: '50%'
	}],
	[{
		value: 90,
		name: ''
	}, {
		value: 10,
		name: '10%'
	}],
	[{
		value: 80,
		name: ''
	}, {
		value: 20,
		name: '20%'
	}],
	[{
		value: 70,
		name: ''
	}, {
		value: 30,
		name: '30%'
	}],
	[{
		value: 60,
		name: ''
	}, {
		value: 40,
		name: '40%'
	}],
	[{
		value: 50,
		name: ''
	}, {
		value: 50,
		name: '50%'
	}]
]
// ppt部分
let pptdata = [
	[{
		value: 90,
		name: ''
	}, {
		value: 10,
		name: '10%'
	}],
	[{
		value: 80,
		name: ''
	}, {
		value: 20,
		name: '20%'
	}],
	[{
		value: 70,
		name: ''
	}, {
		value: 30,
		name: '30%'
	}],
	[{
		value: 60,
		name: ''
	}, {
		value: 40,
		name: '40%'
	}],
	[{
		value: 50,
		name: ''
	}, {
		value: 50,
		name: '50%'
	}],
	[{
		value: 90,
		name: ''
	}, {
		value: 10,
		name: '10%'
	}],
	[{
		value: 80,
		name: ''
	}, {
		value: 20,
		name: '20%'
	}],
	[{
		value: 70,
		name: ''
	}, {
		value: 30,
		name: '30%'
	}],
	[{
		value: 60,
		name: ''
	}, {
		value: 40,
		name: '40%'
	}],
	[{
		value: 50,
		name: ''
	}, {
		value: 50,
		name: '50%'
	}]
]
//互动部分
let hddata = [
	[{
		value: 90,
		name: ''
	}, {
		value: 10,
		name: '10%'
	}],
	[{
		value: 80,
		name: ''
	}, {
		value: 20,
		name: '20%'
	}],
	[{
		value: 70,
		name: ''
	}, {
		value: 30,
		name: '30%'
	}],
	[{
		value: 60,
		name: ''
	}, {
		value: 40,
		name: '40%'
	}],
	[{
		value: 50,
		name: ''
	}, {
		value: 50,
		name: '50%'
	}],
	[{
		value: 90,
		name: ''
	}, {
		value: 10,
		name: '10%'
	}],
	[{
		value: 80,
		name: ''
	}, {
		value: 20,
		name: '20%'
	}],
	[{
		value: 70,
		name: ''
	}, {
		value: 30,
		name: '30%'
	}],
	[{
		value: 60,
		name: ''
	}, {
		value: 40,
		name: '40%'
	}],
	[{
		value: 50,
		name: ''
	}, {
		value: 50,
		name: '50%'
	}]
]
// 雷达图数 表情
let dataemotionone = [
	[
		[5, 9, 56, 1.46, 18, 6, 1]
	],
	[
		[55, 9, 6, 2.46, 18, 6, 1]
	],
	[
		[5, 9, 56, 3.46, 18, 6, 1]
	],
	[
		[55, 8, 56, 4.46, 18, 6, 1]
	],
	[
		[5, 9, 56, 5.46, 18, 6, 1]
	],
	[
		[55, 9, 6, 5.46, 18, 6, 1]
	],
	[
		[5, 9, 56, 4.46, 18, 6, 1]
	],
	[
		[55, 8, 56, 3.46, 18, 6, 1]
	],
	[
		[5, 9, 56, 2.46, 18, 6, 1]
	],
	[
		[55, 8, 56, 3.46, 18, 6, 1]
	]
]
// 雷达图数教学目标等
let dataemotion = [
	[
		[5, 9, 56, 5.46, 18, 6, 1]
	],
	[
		[55, 9, 6, 4.46, 18, 6, 1]
	],
	[
		[5, 9, 56, 3.46, 18, 6, 1]
	],
	[
		[55, 8, 56, 2.46, 18, 6, 1]
	],
	[
		[5, 9, 56, 1.46, 18, 6, 1]
	],
	[
		[55, 9, 6, 5.46, 18, 6, 1]
	],
	[
		[5, 9, 56, 4.46, 18, 6, 1]
	],
	[
		[55, 8, 56, 3.46, 18, 6, 1]
	],
	[
		[5, 9, 56, 2.46, 18, 6, 1]
	],
	[
		[55, 8, 56, 3.46, 18, 6, 1]
	]
]
// 到勤率数据
let comedata = [
	[{
			value: 10,
			name: '提前到课'
		}, {
			value: 30,
			name: '正常上课'
		},
		{
			value: 5,
			name: '迟到≤10min'
		}, {
			value: 4,
			name: '迟到上课'
		},
		{
			value: 8,
			name: '缺勤'
		}
	],
	[{
			value: 10,
			name: '提前到课'
		}, {
			value: 30,
			name: '正常上课'
		},
		{
			value: 5,
			name: '迟到≤10min'
		}, {
			value: 4,
			name: '迟到上课'
		},
		{
			value: 8,
			name: '缺勤'
		}
	],
	[{
			value: 10,
			name: '提前到课'
		}, {
			value: 30,
			name: '正常上课'
		},
		{
			value: 5,
			name: '迟到≤10min'
		}, {
			value: 4,
			name: '迟到上课'
		},
		{
			value: 8,
			name: '缺勤'
		}
	],
	[{
			value: 10,
			name: '提前到课'
		}, {
			value: 30,
			name: '正常上课'
		},
		{
			value: 5,
			name: '迟到≤10min'
		}, {
			value: 4,
			name: '迟到上课'
		},
		{
			value: 8,
			name: '缺勤'
		}
	],
	[{
			value: 10,
			name: '提前到课'
		}, {
			value: 30,
			name: '正常上课'
		},
		{
			value: 5,
			name: '迟到≤10min'
		}, {
			value: 4,
			name: '迟到上课'
		},
		{
			value: 8,
			name: '缺勤'
		}
	],
	[{
			value: 10,
			name: '提前到课'
		}, {
			value: 30,
			name: '正常上课'
		},
		{
			value: 5,
			name: '迟到≤10min'
		}, {
			value: 4,
			name: '迟到上课'
		},
		{
			value: 8,
			name: '缺勤'
		}
	],
	[{
			value: 10,
			name: '提前到课'
		}, {
			value: 30,
			name: '正常上课'
		},
		{
			value: 5,
			name: '迟到≤10min'
		}, {
			value: 4,
			name: '迟到上课'
		},
		{
			value: 8,
			name: '缺勤'
		}
	],
	[{
			value: 10,
			name: '提前到课'
		}, {
			value: 30,
			name: '正常上课'
		},
		{
			value: 5,
			name: '迟到≤10min'
		}, {
			value: 4,
			name: '迟到上课'
		},
		{
			value: 8,
			name: '缺勤'
		}
	],
	[{
			value: 10,
			name: '提前到课'
		}, {
			value: 30,
			name: '正常上课'
		},
		{
			value: 5,
			name: '迟到≤10min'
		}, {
			value: 4,
			name: '迟到上课'
		},
		{
			value: 8,
			name: '缺勤'
		}
	],
	[{
			value: 10,
			name: '提前到课'
		}, {
			value: 30,
			name: '正常上课'
		},
		{
			value: 5,
			name: '迟到≤10min'
		}, {
			value: 4,
			name: '迟到上课'
		},
		{
			value: 8,
			name: '缺勤'
		}
	]
]
let userinfo = [{
		imgurl: 'images/user.jpg',
		name: '李晓华1',
		code: '0752',
		classname: '语文',
		grade: '四年级',
		classcharge: '03班，06班',
		info: '特技教师，优秀教师'
	},
	{
		imgurl: 'images/user.jpg',
		name: '李晓华2',
		code: '0752',
		classname: '语文',
		grade: '四年级',
		classcharge: '03班，06班',
		info: '特技教师，优秀教师'
	},
	{
		imgurl: 'images/user.jpg',
		name: '李晓华3',
		code: '0752',
		classname: '语文',
		grade: '四年级',
		classcharge: '03班，06班',
		info: '特技教师，优秀教师'
	},
	{
		imgurl: 'images/user.jpg',
		name: '李晓华4',
		code: '0752',
		classname: '语文',
		grade: '四年级',
		classcharge: '03班，06班',
		info: '特技教师，优秀教师'
	},
	{
		imgurl: 'images/user.jpg',
		name: '李晓华5',
		code: '0752',
		classname: '语文',
		grade: '四年级',
		classcharge: '03班，06班',
		info: '特技教师，优秀教师'
	},
	{
		imgurl: 'images/user.jpg',
		name: '李晓华6',
		code: '0752',
		classname: '语文',
		grade: '四年级',
		classcharge: '03班，06班',
		info: '特技教师，优秀教师'
	},
	{
		imgurl: 'images/user.jpg',
		name: '李晓华7',
		code: '0752',
		classname: '语文',
		grade: '四年级',
		classcharge: '03班，06班',
		info: '特技教师，优秀教师'
	},
	{
		imgurl: 'images/user.jpg',
		name: '李晓华8',
		code: '0752',
		classname: '语文',
		grade: '四年级',
		classcharge: '03班，06班',
		info: '特技教师，优秀教师'
	},
	{
		imgurl: 'images/user.jpg',
		name: '李晓华9',
		code: '0752',
		classname: '语文',
		grade: '四年级',
		classcharge: '03班，06班',
		info: '特技教师，优秀教师'
	},
	{
		imgurl: 'images/user.jpg',
		name: '李晓华10',
		code: '0752',
		classname: '语文',
		grade: '四年级',
		classcharge: '03班，06班',
		info: '特技教师，优秀教师'
	}
]
// 在线时间
let online = [
	[{
			name: '我的课程',
			onlinehour: 30,
			type: 'ligthgreen'
		},
		{
			name: '在线编辑',
			onlinehour: 100,
			type: 'ligthblue'
		},
		{
			name: '我的直播',
			onlinehour: 20,
			type: 'ligthpink'
		},
		{
			name: '讨论区',
			onlinehour: 40,
			type: 'ligthpurple'
		}
	],
	[{
			name: '我的课程',
			onlinehour: 30,
			type: 'ligthgreen'
		},
		{
			name: '在线编辑',
			onlinehour: 10,
			type: 'ligthblue'
		},
		{
			name: '我的直播',
			onlinehour: 20,
			type: 'ligthpink'
		},
		{
			name: '讨论区',
			onlinehour: 40,
			type: 'ligthpurple'
		}
	],
	[{
			name: '我的课程',
			onlinehour: 30,
			type: 'ligthgreen'
		},
		{
			name: '在线编辑',
			onlinehour: 100,
			type: 'ligthblue'
		},
		{
			name: '我的直播',
			onlinehour: 20,
			type: 'ligthpink'
		},
		{
			name: '讨论区',
			onlinehour: 40,
			type: 'ligthpurple'
		}
	],
	[{
			name: '我的课程',
			onlinehour: 30,
			type: 'ligthgreen'
		},
		{
			name: '在线编辑',
			onlinehour: 10,
			type: 'ligthblue'
		},
		{
			name: '我的直播',
			onlinehour: 22,
			type: 'ligthpink'
		},
		{
			name: '讨论区',
			onlinehour: 40,
			type: 'ligthpurple'
		}
	],
	[{
			name: '我的课程',
			onlinehour: 30,
			type: 'ligthgreen'
		},
		{
			name: '在线编辑',
			onlinehour: 10,
			type: 'ligthblue'
		},
		{
			name: '我的直播',
			onlinehour: 20,
			type: 'ligthpink'
		},
		{
			name: '讨论区',
			onlinehour: 40,
			type: 'ligthpurple'
		}
	],
	[{
			name: '我的课程',
			onlinehour: 30,
			type: 'ligthgreen'
		},
		{
			name: '在线编辑',
			onlinehour: 10,
			type: 'ligthblue'
		},
		{
			name: '我的直播',
			onlinehour: 20,
			type: 'ligthpink'
		},
		{
			name: '讨论区',
			onlinehour: 40,
			type: 'ligthpurple'
		}
	],
	[{
			name: '我的课程',
			onlinehour: 30,
			type: 'ligthgreen'
		},
		{
			name: '在线编辑',
			onlinehour: 10,
			type: 'ligthblue'
		},
		{
			name: '我的直播',
			onlinehour: 2,
			type: 'ligthpink'
		},
		{
			name: '讨论区',
			onlinehour: 40,
			type: 'ligthpurple'
		}
	],
	[{
			name: '我的课程',
			onlinehour: 30,
			type: 'ligthgreen'
		},
		{
			name: '在线编辑',
			onlinehour: 10,
			type: 'ligthblue'
		},
		{
			name: '我的直播',
			onlinehour: 20,
			type: 'ligthpink'
		},
		{
			name: '讨论区',
			onlinehour: 4,
			type: 'ligthpurple'
		}
	],
	[{
			name: '我的课程',
			onlinehour: 30,
			type: 'ligthgreen'
		},
		{
			name: '在线编辑',
			onlinehour: 10,
			type: 'ligthblue'
		},
		{
			name: '我的直播',
			onlinehour: 0,
			type: 'ligthpink'
		},
		{
			name: '讨论区',
			onlinehour: 4,
			type: 'ligthpurple'
		}
	],
	[{
			name: '我的课程',
			onlinehour: 30,
			type: 'ligthgreen'
		},
		{
			name: '在线编辑',
			onlinehour: 10,
			type: 'ligthblue'
		},
		{
			name: '我的直播',
			onlinehour: 22,
			type: 'ligthpink'
		},
		{
			name: '讨论区',
			onlinehour: 40,
			type: 'ligthpurple'
		}
	]
]
// 访问总量
let visitlist = [
	[{
			name: '春天来了',
			visitnum: 300,
			type: 'ligthgreen'
		},
		{
			name: '柳叶红了',
			visitnum: 100,
			type: 'ligthblue'
		},
		{
			name: '我的父亲',
			visitnum: 220,
			type: 'ligthpink'
		},
		{
			name: '大海天空',
			visitnum: 400,
			type: 'ligthpurple'
		}
	],
	[{
			name: '春天来了',
			visitnum: 300,
			type: 'ligthgreen'
		},
		{
			name: '柳叶红了',
			visitnum: 100,
			type: 'ligthblue'
		},
		{
			name: '我的父亲',
			visitnum: 220,
			type: 'ligthpink'
		},
		{
			name: '大海天空',
			visitnum: 400,
			type: 'ligthpurple'
		}
	],
	[{
			name: '春天来了',
			visitnum: 300,
			type: 'ligthgreen'
		},
		{
			name: '柳叶红了',
			visitnum: 100,
			type: 'ligthblue'
		},
		{
			name: '我的父亲',
			visitnum: 220,
			type: 'ligthpink'
		},
		{
			name: '大海天空',
			visitnum: 400,
			type: 'ligthpurple'
		}
	],
	[{
			name: '春天来了',
			visitnum: 300,
			type: 'ligthgreen'
		},
		{
			name: '柳叶红了',
			visitnum: 100,
			type: 'ligthblue'
		},
		{
			name: '我的父亲',
			visitnum: 220,
			type: 'ligthpink'
		},
		{
			name: '大海天空',
			visitnum: 400,
			type: 'ligthpurple'
		}
	],
	[{
			name: '春天来了',
			visitnum: 300,
			type: 'ligthgreen'
		},
		{
			name: '柳叶红了',
			visitnum: 100,
			type: 'ligthblue'
		},
		{
			name: '我的父亲',
			visitnum: 220,
			type: 'ligthpink'
		},
		{
			name: '大海天空',
			visitnum: 400,
			type: 'ligthpurple'
		}
	],
	[{
			name: '春天来了',
			visitnum: 300,
			type: 'ligthgreen'
		},
		{
			name: '柳叶红了',
			visitnum: 100,
			type: 'ligthblue'
		},
		{
			name: '我的父亲',
			visitnum: 220,
			type: 'ligthpink'
		},
		{
			name: '大海天空',
			visitnum: 400,
			type: 'ligthpurple'
		}
	],
	[{
			name: '春天来了',
			visitnum: 300,
			type: 'ligthgreen'
		},
		{
			name: '柳叶红了',
			visitnum: 100,
			type: 'ligthblue'
		},
		{
			name: '我的父亲',
			visitnum: 220,
			type: 'ligthpink'
		},
		{
			name: '大海天空',
			visitnum: 400,
			type: 'ligthpurple'
		}
	],
	[{
			name: '春天来了',
			visitnum: 300,
			type: 'ligthgreen'
		},
		{
			name: '柳叶红了',
			visitnum: 100,
			type: 'ligthblue'
		},
		{
			name: '我的父亲',
			visitnum: 220,
			type: 'ligthpink'
		},
		{
			name: '大海天空',
			visitnum: 400,
			type: 'ligthpurple'
		}
	],
	[{
			name: '春天来了',
			visitnum: 300,
			type: 'ligthgreen'
		},
		{
			name: '柳叶红了',
			visitnum: 100,
			type: 'ligthblue'
		},
		{
			name: '我的父亲',
			visitnum: 220,
			type: 'ligthpink'
		},
		{
			name: '大海天空',
			visitnum: 400,
			type: 'ligthpurple'
		}
	],
	[{
			name: '春天来了',
			visitnum: 300,
			type: 'ligthgreen'
		},
		{
			name: '柳叶红了',
			visitnum: 100,
			type: 'ligthblue'
		},
		{
			name: '我的父亲',
			visitnum: 220,
			type: 'ligthpink'
		},
		{
			name: '大海天空',
			visitnum: 400,
			type: 'ligthpurple'
		}
	]
]
// 录制数据
let recordinfo = [{
		classnum: 100,
		videonum: 100,
		knowlegenum: 100,
		microvideonum: 100,
		livenum: 100,
		filenum: 100,
		exercisenum: 100
	},
	{
		classnum: 100,
		videonum: 100,
		knowlegenum: 100,
		microvideonum: 100,
		livenum: 100,
		filenum: 100,
		exercisenum: 100
	},
	{
		classnum: 100,
		videonum: 100,
		knowlegenum: 100,
		microvideonum: 100,
		livenum: 100,
		filenum: 100,
		exercisenum: 100
	},
	{
		classnum: 100,
		videonum: 100,
		knowlegenum: 100,
		microvideonum: 100,
		livenum: 100,
		filenum: 100,
		exercisenum: 100
	},
	{
		classnum: 100,
		videonum: 100,
		knowlegenum: 100,
		microvideonum: 100,
		livenum: 100,
		filenum: 100,
		exercisenum: 100
	},
	{
		classnum: 100,
		videonum: 100,
		knowlegenum: 100,
		microvideonum: 100,
		livenum: 100,
		filenum: 100,
		exercisenum: 100
	},
	{
		classnum: 100,
		videonum: 100,
		knowlegenum: 100,
		microvideonum: 100,
		livenum: 100,
		filenum: 100,
		exercisenum: 100
	},
	{
		classnum: 100,
		videonum: 100,
		knowlegenum: 100,
		microvideonum: 100,
		livenum: 100,
		filenum: 100,
		exercisenum: 100
	},
	{
		classnum: 100,
		videonum: 100,
		knowlegenum: 100,
		microvideonum: 100,
		livenum: 100,
		filenum: 100,
		exercisenum: 100
	},
	{
		classnum: 100,
		videonum: 100,
		knowlegenum: 100,
		microvideonum: 100,
		livenum: 100,
		filenum: 100,
		exercisenum: 100
	},
]
// 最后一个文本
let txtinfo = [{
		percent: 70,
		txtone: '一个人一旦经历了磨难和坎坷1，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txttwo: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txtthree: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。'
	},
	{
		percent: 60,
		txtone: '一个人一旦经历了磨难和坎坷2，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txttwo: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txtthree: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。'
	},
	{
		percent: 50,
		txtone: '一个人一旦经历了磨难和坎坷3，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txttwo: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txtthree: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。'
	},
	{
		percent: 40,
		txtone: '一个人一旦经历了磨难和坎坷4，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txttwo: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txtthree: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。'
	},
	{
		percent: 30,
		txtone: '一个人一旦经历了磨难和坎坷5，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txttwo: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txtthree: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。'
	},
	{
		percent: 20,
		txtone: '一个人一旦经历了磨难和坎坷6，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txttwo: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txtthree: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。'
	},
	{
		percent: 10,
		txtone: '一个人一旦经历了磨难和坎坷7，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txttwo: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txtthree: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。'
	},
	{
		percent: 80,
		txtone: '一个人一旦经历了磨难和坎坷8，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txttwo: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txtthree: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。'
	},
	{
		percent: 90,
		txtone: '一个人一旦经历了磨难和坎坷9，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txttwo: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txtthree: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。'
	},
	{
		percent: 70,
		txtone: '一个人一旦经历了磨难和坎坷0，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txttwo: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。',
		txtthree: '一个人一旦经历了磨难和坎坷，就会对人生有一个深刻的认识。哲学家说，灵魂和肉体，就像锋利的刀刃一样，须臾不可分离。'
	}
]
// 活动区域分析数据
let Dactiveinfo = [{
		imgurl: 'images/jiangtaiyllow.png',
		black: 63,
		screenval: 10,
		student: 40,
		hyzs: 0,
		cyzs: 5
	},
	{
		imgurl: 'images/jiangtaiyllow.png',
		black: 63,
		screenval: 60,
		student: 40,
		hyzs: 5,
		cyzs: 5
	},
	{
		imgurl: 'images/jiangtaiyllow.png',
		black: 63,
		screenval: 50,
		student: 40,
		hyzs: 6,
		cyzs: 5
	},
	{
		imgurl: 'images/jiangtaiyllow.png',
		black: 63,
		screenval: 40,
		student: 40,
		hyzs: 0,
		cyzs: 5
	},
	{
		imgurl: 'images/jiangtaiyllow.png',
		black: 63,
		screenval: 13,
		student: 40,
		hyzs: 7,
		cyzs: 5
	},
	{
		imgurl: 'images/jiangtaiyllow.png',
		black: 63,
		screenval: 12,
		student: 40,
		hyzs: 9,
		cyzs: 5
	},
	{
		imgurl: 'images/jiangtaiyllow.png',
		black: 63,
		screenval: 10,
		student: 10,
		hyzs: 1,
		cyzs: 5
	},
	{
		imgurl: 'images/jiangtaiyllow.png',
		black: 63,
		screenval: 10,
		student: 40,
		hyzs: 2,
		cyzs: 5
	},
	{
		imgurl: 'images/jiangtaiyllow.png',
		black: 13,
		screenval: 10,
		student: 40,
		hyzs: 3,
		cyzs: 5
	},
	{
		imgurl: 'images/jiangtaiyllow.png',
		black: 63,
		screenval: 20,
		student: 40,
		hyzs: 4,
		cyzs: 5
	}
]
// 标签云
let labellist = [
	[{
			name: 'a'
		}, {
			name: 'b'
		}, {
			name: 'c'
		}, {
			name: 'd'
		}, {
			name: 'e'
		},
		{
			name: 'f'
		}, {
			name: 'g'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}, {
			name: '标签10'
		},
		{
			name: '标签5'
		}, {
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}
	],
	[{
			name: '标签1'
		}, {
			name: '标签2'
		}, {
			name: '标签3'
		}, {
			name: '标签4'
		}, {
			name: '标签5'
		},
		{
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}, {
			name: '标签10'
		},
		{
			name: '标签5'
		}, {
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}
	],
	[{
			name: '标签1'
		}, {
			name: '标签2'
		}, {
			name: '标签3'
		}, {
			name: '标签4'
		}, {
			name: '标签5'
		},
		{
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}, {
			name: '标签10'
		},
		{
			name: '标签5'
		}, {
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}
	],
	[{
			name: '标签1'
		}, {
			name: '标签2'
		}, {
			name: '标签3'
		}, {
			name: '标签4'
		}, {
			name: '标签5'
		},
		{
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}, {
			name: '标签10'
		},
		{
			name: '标签5'
		}, {
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}
	],
	[{
			name: '标签1'
		}, {
			name: '标签2'
		}, {
			name: '标签3'
		}, {
			name: '标签4'
		}, {
			name: '标签5'
		},
		{
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}, {
			name: '标签10'
		},
		{
			name: '标签5'
		}, {
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}
	],
	[{
			name: '标签1'
		}, {
			name: '标签2'
		}, {
			name: '标签3'
		}, {
			name: '标签4'
		}, {
			name: '标签5'
		},
		{
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}, {
			name: '标签10'
		},
		{
			name: '标签5'
		}, {
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}
	],
	[{
			name: '标签1'
		}, {
			name: '标签2'
		}, {
			name: '标签3'
		}, {
			name: '标签4'
		}, {
			name: '标签5'
		},
		{
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}, {
			name: '标签10'
		},
		{
			name: '标签5'
		}, {
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}
	],
	[{
			name: '标签1'
		}, {
			name: '标签2'
		}, {
			name: '标签3'
		}, {
			name: '标签4'
		}, {
			name: '标签5'
		},
		{
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}, {
			name: '标签10'
		},
		{
			name: '标签5'
		}, {
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}
	],
	[{
			name: '标签1'
		}, {
			name: '标签2'
		}, {
			name: '标签3'
		}, {
			name: '标签4'
		}, {
			name: '标签5'
		},
		{
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}, {
			name: '标签10'
		},
		{
			name: '标签5'
		}, {
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}
	],
	[{
			name: '标签1'
		}, {
			name: '标签2'
		}, {
			name: '标签3'
		}, {
			name: '标签4'
		}, {
			name: '标签5'
		},
		{
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}, {
			name: '标签10'
		},
		{
			name: '标签5'
		}, {
			name: '标签6'
		}, {
			name: '标签7'
		}, {
			name: '标签8'
		}, {
			name: '标签9'
		}
	]
]
// 界面实例化
new Vue({
	el: '#app',
	data: {
		seconds: 20000, // 刷新时间间隔，五秒的倍数
		zztseconds: 4000, // 柱状图刷新间隔
		countindex: 0,
		zzttitle: indicator[0].name,
		labellist: labellist[0],
		activeinfo: Dactiveinfo[0],
		txtinfo: txtinfo[0],
		recordinfo: recordinfo[0],
		visitlist: visitlist[0],
		userinfo: userinfo[0],
		onlinelist: online[0],
		visittotal: 0,
		hyzsrandomval: 0,
		cyzsrandomval: 0,
		clearinterval: null,
		radarclearinterval: null,
		radarcount: 0,
		comelegend: ['提前到课', '正常上课', '迟到≤10min', '迟到上课', '缺勤'],
		emotionareacolor: [
			'rgba(0, 113, 255, 0.1)',
			'rgba(0, 113, 255, 0.2)',
			'rgba(0, 113, 255, 0.4)',
			'rgba(0, 113, 255, 0.6)',
			'rgba(0, 113, 255, 0.8)',
			'rgba(0, 113, 255, 1)'
		], // 雷达图分割线配色
		emotionnamecolor: 'rgb(255, 255, 255)', // 雷达图名称配色
		emotionaxisLinecolor: 'rgba(0, 113, 255, 0.5)', // 雷达图线条（圆圈）颜色
		emotionseriescolor: '#0071ff', // 雷达图面积色
		hyzscolor: ['#ffce4d', '#ffb900'], // 活跃指数配色
		cyzscolor: ['#09c100', '#0cf700'], // 参与指数配色
		stcolor: ['#0caffc', '#00608e'], // 师生互动配色
		pptcolor: ['#ffce4d', '#be8a00'], // ppt配色
		hdcolor: ['#f97c8a', '#a84c57'], // 互动配色
		bscolor: ['#29cdcc', '#005756'], // 板书配色
		emotioncolor: ['#0caffc', '#29cdcc', '#ffce4d', '#f97c8a', '#a391ff'], // 教学目标配色
		emotiononecolor: ['#0caffc', '#29cdcc', '#ffce4d', '#f97c8a', '#a391ff'], // 表情配色
		comecolor: ['#0caffc', '#29cdcc', '#ffce4d', '#f97c8a', '#a391ff'], // 到勤率配色
		onlinetotal: 0
	},
	created() {
		// 计算访问总量
		this.visittotal = 0
		for(let item = 0; item < this.visitlist.length; item++) {
			this.visittotal += this.visitlist[item].visitnum
		}
		this.onlinetotal = 0
		for(let item = 0; item < this.onlinelist.length; item++) {
			this.onlinetotal += this.onlinelist[item].onlinehour
		}
	},
	components: {
		'aa': {
			props: ['aas'],
			template: '<div><span v-for="item in aas">{{ item }}</span></div>'
		},
		progresss: {
			props: ['val', 'classname', 'num'],
			template: '<div class="progress"><span class="bg" :class="classname" :style="width:(val > num ? num : va)px"></span></div>'
		}
	},
	methods: {
		hyzs(val, id, color) {
			// 基于准备好的dom，初始化echarts实例
			let obj = document.getElementById(id)
			var myChart = echarts.init(obj);
			// 指定图表的配置项和数据
			option = {
				color: color,
				series: [{
					name: '访问来源',
					type: 'pie',
					radius: ['55%', '100%'],
					labelLine: {
						normal: {
							show: false
						}
					},
					data: [{
							value: 180,
							name: ''
						},
						{
							value: 180,
							name: ''
						}
					],
					hoverAnimation: false
				}]
			}
			// 使用刚指定的配置项和数据显示图表。
			myChart.setOption(option);
			obj.setAttribute('style', 'transform: rotate(' + (-90 + (val / 10) * 100 * 1.8) + 'deg);')
		},
		bs(id, color, dataval) {
			// 基于准备好的dom，初始化echarts实例
			let obj = document.getElementById(id)
			var myChart = echarts.init(obj);

			// 指定图表的配置项和数据
			option = {
				color: color,
				series: [{
						name: '访问来源',
						type: 'pie',
						selectedMode: 'single',
						radius: [0, '40%'],
						label: {
							normal: {
								position: 'center',
								show: true,
								color: '#fff'
							}
						},
						labelLine: {
							normal: {
								show: false
							}
						},
						lineHeight: 50,
						data: [{
							value: 100,
							name: dataval[1].name
						}],
						hoverAnimation: false
					},
					{
						name: '访问来源',
						type: 'pie',
						radius: ['70%', '100%'],
						data: dataval,
						labelLine: {
							normal: {
								show: false
							}
						},
						hoverAnimation: false
					}
				]
			}
			// 使用刚指定的配置项和数据显示图表。
			myChart.setOption(option);
		},
		come(id, color, data) {
			// 基于准备好的dom，初始化echarts实例
			let obj = document.getElementById(id)
			var myChart = echarts.init(obj);
			// 指定图表的配置项和数据
			option = {
				color: color,
				tooltip: {
					trigger: 'item',
					formatter: "{d}%"
				},
				legend: {
					orient: 'vertical',
					left: 'left',
					data: this.comelegend,
					textStyle: {
						color: '#fff'
					}
				},
				series: [{
					name: '访问来源',
					type: 'pie',
					radius: '70%',
					center: ['65%', '60%'],
					label: {
						normal: {
							formatter: '{d}%'
						}
					},
					labelLine: {
						normal: {
							length: 5
						}
					},
					data: data,
					itemStyle: {
						emphasis: {
							shadowBlur: 10,
							shadowOffsetX: 0,
							shadowColor: 'rgba(0, 0, 0, 0.5)'
						}
					}
				}]
			}
			// 使用刚指定的配置项和数据显示图表。
			myChart.setOption(option);
		},
		emotion(id, color, data, indicator) {
			let that = this
			// 基于准备好的dom，初始化echarts实例
			let obj = document.getElementById(id)
			var myChart = echarts.init(obj);

			// 指定图表的配置项和数据
			option = {
				color: color,
				radar: {
					indicator: indicator,
					shape: 'circle',
					splitNumber: 5,
					triggerEvent: true,
					name: {
						textStyle: {
							color: this.emotionnamecolor,
							fontSize: 16
						}
					},
					splitLine: {
						lineStyle: {
							color: this.emotionareacolor.reverse()
						}
					},
					splitArea: {
						show: false
					},
					axisLine: {
						lineStyle: {
							color: this.emotionaxisLinecolor
						}
					}
				},
				series: [{
					name: '北京',
					type: 'radar',
					clickable: true,
					lineStyle: {
						normal: {
							width: 1,
							opacity: 0.5
						}
					},
					label: {
						normal: {
							fontSize: 18
						}
					},
					data: data,
					symbol: 'none',
					itemStyle: {
						normal: {
							color: this.emotionseriescolor
						}
					},
					areaStyle: {
						normal: {
							opacity: 0.1
						}
					}
				}]
			};
			// 使用刚指定的配置项和数据显示图表。
			myChart.setOption(option);
			// 处理点击事件并且跳转到相应的百度搜索页面
			myChart.on('click', function(params) {
				console.log(params, 'paramsparamsparams')
				// window.open('https://www.baidu.com/s?wd=' + encodeURIComponent(params.name));
				that.changezzt(params)
			});
		},
		changezzt(params) {
			this.zztdatafn(params, zztdata[this.countindex])
		},
		zztdatafn(params, flag) {
			let that = this
			that.zzttitle = params.name
			if(params.name === '教学态度') {
				// 柱状图
				that.zzt('zzt', flag.data[0], flag.zztxaxis[0])
				that.radarcount = 0
			}
			if(params.name === '教学内容') {
				// 柱状图
				that.zzt('zzt', flag.data[1], flag.zztxaxis[1])
				that.radarcount = 1
			}
			if(params.name === '教学方法') {
				// 柱状图
				that.zzt('zzt', flag.data[2], flag.zztxaxis[2])
				that.radarcount = 2
			}
			if(params.name === '教学效果') {
				// 柱状图
				that.zzt('zzt', flag.data[3], flag.zztxaxis[3])
				that.radarcount = 3
			}
			if(params.name === '教学目标') {
				// 柱状图
				that.zzt('zzt', flag.data[4], flag.zztxaxis[4])
				that.radarcount = 4
			}
		},
		zzt(id, data, zztxaxis) {
			// 基于准备好的dom，初始化echarts实例
			let obj = document.getElementById(id)
			var myChart = echarts.init(obj);
			option = {
				title: {
					text: this.zzttitle,
					textStyle: {
						color: '#fff',
						fontSize: 16
					},
					left: '43%',
					top: '17'
				},
				xAxis: {
					data: zztxaxis,
					axisLabel: {
						show: true,
						textStyle: {
							color: '#fff'
						},
						interval: 0
					},
					z: 10,
					offset: 0
				},
				yAxis: {
					axisLabel: {
						textStyle: {
							color: '#fff',

						}
					}
				},
				series: [{
					type: 'bar',
					barMaxWidth: 30,
					animation: true,
					itemStyle: {
						normal: {
							color: new echarts.graphic.LinearGradient(
								0, 0, 0, 1, [{
										offset: 0,
										color: '#57fab7'
									},
									{
										offset: 0.3,
										color: '#29cdcc'
									},
									{
										offset: 0.6,
										color: '#0caffc'
									},
									{
										offset: 1,
										color: '#0071ff'
									}
								]
							)
						}
					},
					data: data
				}]
			};
			// 使用刚指定的配置项和数据显示图表。
			myChart.setOption(option);
		},
		randomval() {
			return parseInt(Math.random() * 10)
		},
		exefn() {
			console.log(this.countindex, 'this.countindexthis.countindex')
			// 标签云
			this.labellist = labellist[this.countindex]

			// 讲台区域
			this.activeinfo = Dactiveinfo[this.countindex]
			// 文本区域
			this.txtinfo = txtinfo[this.countindex]
			// 录制课程
			this.recordinfo = recordinfo[this.countindex]
			// 访问总量
			this.visitlist = visitlist[this.countindex]
			this.visittotal = 0
			for(let item = 0; item < this.visitlist.length; item++) {
				this.visittotal += this.visitlist[item].visitnum
			}
			// 用户信息
			this.userinfo = userinfo[this.countindex]
			// 在线时间
			this.onlinelist = online[this.countindex]
			this.onlinetotal = 0
			for(let item = 0; item < this.onlinelist.length; item++) {
				this.onlinetotal += this.onlinelist[item].onlinehour
			}
			// 活跃指数部分
			this.hyzsrandomval = this.activeinfo.hyzs
			this.cyzsrandomval = this.activeinfo.cyzs
			this.hyzs(this.activeinfo.hyzs, 'hyzs', this.hyzscolor)
			this.hyzs(this.activeinfo.cyzs, 'cyzs', this.cyzscolor)
			// 板书部分
			this.bs('st', this.stcolor, stdata[this.countindex])
			this.bs('ppt', this.pptcolor, pptdata[this.countindex])
			this.bs('hd', this.hdcolor, hddata[this.countindex])
			this.bs('bs', this.bscolor, bsdata[this.countindex])
			// 柱状图
			this.changezzt(indicator[0])
			let changezztcount = 0
			if(this.radarclearinterval) {
				clearInterval(this.radarclearinterval)
			}
			let that = this
			this.radarclearinterval = setInterval(function() {
				that.radarcount++
					if(that.radarcount >= 5) {
						that.radarcount = 0
					}
				that.changezzt(indicator[that.radarcount], that.radarcount)
			}, that.zztseconds)

			//			this.zzt('zzt', zztdata[this.countindex])
			// 雷达图
			this.emotion('emotion', this.emotioncolor, dataemotion[this.countindex], indicator)
			// 雷达图表情
			this.emotion('emotionone', this.emotiononecolor, dataemotionone[this.countindex], indicatorone)
			// 到勤率
			this.come('come', this.comecolor, comedata[this.countindex])
			//			if(window.innit) {
			//				window.innit()
			//				window.animate()
			//			}
		}
	},
	mounted() {
		let that = this
		this.exefn()
		// 定时器，每隔10秒钟刷新一次数据
		this.clearinterval = setInterval(function() {
			that.countindex++
				if(that.countindex >= 10) {
					that.countindex = 0
				}
			that.exefn()
		}, that.seconds)
	},
	beforeDestroy() {
		clearInterval(this.clearinterval)
		if(this.radarclearinterval) {
			clearInterval(this.radarclearinterval)
		}
	}
})